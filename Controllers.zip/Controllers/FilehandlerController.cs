﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MBoardapp.Controllers
{
    [RoutePrefix("File")]
    public class FilehandlerController : ApiController
    {
        [Route("FileValidation")]
        public IHttpActionResult PostFileValidation()
        {
            var httpRequest = HttpContext.Current.Request;
            string UserProfilePic = null;
            var UserProfile = httpRequest.Files["ProfilePic"];
            String UserPicExt = Path.GetExtension(UserProfile.FileName);
            string mimetype = UserProfile.ContentType;

            if (mimetype == "image/jpeg" || mimetype == "image/jpg" || mimetype == "image/pjpeg"
                   || mimetype == "image/png" || mimetype == "application/x-jpg" || mimetype == "image/pipeg" || mimetype == "image/vnd.swiftview-jpeg"
                   || mimetype == "application/msword" || mimetype == "application/vnd.ms-excel" || mimetype == "application/pdf" || mimetype == "text/plain"
                   || mimetype == "application/vnd.ms-powerpoint" || mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                   || mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            {
                if ((UserPicExt.ToLower() == ".jpg" || UserPicExt.ToLower() == ".jpeg" || UserPicExt.ToLower() == ".pdf"
                || UserPicExt.ToLower() == ".png" || UserPicExt.ToLower() == ".doc" || UserPicExt.ToLower() == ".docx" ||
                UserPicExt.ToLower() == ".xls" || UserPicExt.ToLower() == ".xlsx" || UserPicExt.ToLower() == ".ppt" ||
                UserPicExt.ToLower() == ".pptx" || UserPicExt.ToLower() == ".txt"))
                {
                    if (UserProfile.ContentLength > 5242880)
                    {
                        return BadRequest("File size should not exceed the limit of 5 MB");
                    }
                    else
                    {
                        return Ok("S");
                    }
                }
                else
                {
                    return BadRequest("File Extension is Not Allowed");
                }
            }
            else
            {
                return BadRequest("File Extension is Not Allowed");
            }
        }

        [Route("PicValidation")]
        public IHttpActionResult PostPicValidation()
        {
            var httpRequest = HttpContext.Current.Request;
            string UserProfilePic = null;
            var UserProfile = httpRequest.Files["ProfilePic"];
            String UserPicExt = Path.GetExtension(UserProfile.FileName);
            string mimetype = UserProfile.ContentType;

            if (mimetype == "image/jpeg" || mimetype == "image/jpg" || mimetype == "image/pjpeg"
                   || mimetype == "image/png" || mimetype == "application/x-jpg" || mimetype == "image/pipeg" || mimetype == "image/vnd.swiftview-jpeg")
            {
                if ((UserPicExt.ToLower() == ".jpg" || UserPicExt.ToLower() == ".jpeg"
                || UserPicExt.ToLower() == ".png"))
                {
                    if (UserProfile.ContentLength > 1048576)
                    {
                        return BadRequest("File Size Can not be exceed than 1 MB");
                    }
                    else
                    {
                        return Ok("S");
                    }
                }
                else
                {
                    return BadRequest("File Extension is Not Allowed");
                }
            }
            else
            {
                return BadRequest("File Extension is Not Allowed");
            }
        }
    }
}

﻿using MBoardapp.Models;
using MBoardapp.Repository;
using SRVTextToImage;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web;
using MBoardapp.Filters;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using MBoardapp.FormDataModels;
using System.Configuration;

namespace MBoardapp.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("SuperAdmin")]
    public class SuperAdminController : ApiController
    {
        SuperAdminContext da = new SuperAdminContext();
        Common objCom = new Common();
        DisplayMessage displayMessage = new DisplayMessage();
        /// <summary>
        /// Captha Image
        /// </summary>
        /// <remarks>
        /// After Hit on this api you got a Captcha Image 
        /// </remarks>
        /// <returns></returns>
        [Route("Captcha")]
        public HttpResponseMessage GetCaptcha()
        {
            var resp = new HttpResponseMessage();
            string[] array = CaptchaImage.CreateRandomText(1);
            CaptchaRandomImage ci = new CaptchaRandomImage();
            string d1 = array[0].ToString();
            string d2 = array[1].ToString();
            System.Web.HttpContext.Current.Application["a"] = d1;
            ci.GenerateImage(d2 + " =", 150, 40, Color.Black, Color.White);
            var stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            resp.Content = new StreamContent(stream);
            resp.Content.Headers.ContentType =
        new MediaTypeHeaderValue("image/png");
            return resp;

        }
        /// <summary>
        /// Super Admin Login
        /// </summary>
        /// <remarks>
        /// All Fields Are Required
        /// </remarks>
        /// <returns></returns>
        [ValidateModel]
        [Route("Login")]
        public IHttpActionResult PostSuperAdminLogin(SuperAdminModel loginData)
        {
            if (ModelState.IsValid)
            {
                string capvalue = HttpContext.Current.Application["a"].ToString();
                if (loginData.Captcha == capvalue)
                {
                    SuperAdminAfterLoginModel data = da.SuperAdminLogin(loginData.UserName);
                    if (data != null)
                    {

                        string dbpas = objCom.SingleHashing(loginData.Password);
                        if (dbpas == data.Password)
                        {
                            displayMessage.response = "Success";
                            displayMessage.error = "";
                            displayMessage.message = "Login successfull";
                            displayMessage.result = new { data.Id, data.UserName };
                            return Ok(displayMessage);
                        }
                        else
                        {
                            displayMessage.response = "Fail";
                            displayMessage.error = "Entered Password is incorrect. Please enter correct password.";
                            displayMessage.message = "";
                            displayMessage.result = new { };
                            return Content(HttpStatusCode.BadRequest, displayMessage);
                        }

                    }
                    else
                    {
                        displayMessage.response = "Fail";
                        displayMessage.error = "Please Enter Valid UserName.";
                        displayMessage.message = "";
                        displayMessage.result = new { };
                        return Content(HttpStatusCode.BadRequest, displayMessage);

                    }
                }
                else
                {
                    displayMessage.response = "Fail";
                    displayMessage.error = "Entered Captcha value is incorrect. Please enter correct Captcha value.";
                    displayMessage.message = "";
                    displayMessage.result = new { };
                    return Content(HttpStatusCode.BadRequest, displayMessage);
                }
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "Please add Values For Required Fields.";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
        /// <summary>
        /// Get Super Admin Profile Info
        /// </summary>
        /// <remarks>
        /// Submit The Id of SuperAdmin To Get The Profile Info
        /// </remarks>
        /// <param name="Id">
        /// Submit The SuperAdmin Id
        /// </param>
        /// <returns></returns>
        [Route("Profile/{Id}")]
        public IHttpActionResult GetSuperAdminProfile(int Id)
        {
            if (Id > 0)
            {
                SuperAdminProfileData data = da.SuperAdminProfile(Id);
                if (data != null)
                {
                    displayMessage.response = "Success";
                    displayMessage.error = "";
                    displayMessage.message = "";
                    displayMessage.result = data;
                    return Ok(displayMessage);
                }
                else
                {
                    displayMessage.response = "Fail";
                    displayMessage.error = "No Data Found";
                    displayMessage.message = "";
                    displayMessage.result = new { };
                    return Content(HttpStatusCode.BadRequest, displayMessage);
                }
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "Please Provide Id First";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
        /// <summary>
        /// Create New Department
        /// </summary>
        /// <remarks>
        /// 1. All Fields are Required
        /// 2. Department Logo size not exceeded more than 100 kb and should be png type
        /// </remarks>
        /// <returns></returns>
        [ValidateModel]
        [Route("Department")]
        [DepartmentModel.SwaggerFormAttribute()]
        public IHttpActionResult PostDepartment()
        {
            if (ModelState.IsValid)
            {
                string imageName = "";
                var httpRequest = HttpContext.Current.Request;
                AddDepartmentModel dptModel = new AddDepartmentModel();
                dptModel.DepartmentName = httpRequest["DepartmentName"];
                dptModel.Title = httpRequest["Title"];
                dptModel.Address = httpRequest["Address"];
                dptModel.Email = httpRequest["Email"];
                dptModel.Mobile = httpRequest["Mobile"];
                var logo = httpRequest.Files["Logo"];
                string msgid = DateTime.Now.ToString("ssff");
                dptModel.DepartmentId = dptModel.DepartmentName.Substring(0, 3) + Guid.NewGuid().ToString("N").Substring(0, 3);
                if (logo != null)
                {
                    imageName = new String(Path.GetFileNameWithoutExtension(logo.FileName).Take(10).ToArray()).Replace(" ", "-");
                    imageName = imageName + DateTime.Now.ToString("mmssff") + Path.GetExtension(logo.FileName);
                    var filePath = HttpContext.Current.Server.MapPath("~/DepartmentLogo/" + imageName);
                    logo.SaveAs(filePath);
                    dptModel.Logo = imageName;
                }
                dptModel.UserName = dptModel.DepartmentName + "-admin";
                var DisplayPassword = CGeneral.GetRendomPassword(8);
                dptModel.Password = objCom.SingleHashing(DisplayPassword);
                String Msg = Convert.ToString(ConfigurationManager.AppSettings["DepartmentCredentialsMsg"]).Replace("[Dptid]", dptModel.DepartmentId).Replace("[Username]", dptModel.UserName).Replace("[Pass]", DisplayPassword);
                DepartmentDataAfterAdd data = da.DepartmentRegistration(dptModel);
                SMSSender.SMSSend(Msg, data.Mobile);
                displayMessage.response = "Success";
                displayMessage.error = "";
                displayMessage.message = "Department Created Successfully";
                displayMessage.result = data;
                return Created("", displayMessage);
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "Please Provide data for Required Fields";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
        /// <summary>
        /// Get the Departments List
        /// </summary>
        /// <remarks>
        /// Call This URI to get all the departments in list format
        /// </remarks>
        /// <returns></returns>
        [Route("DepartmentList")]
        public IHttpActionResult GetDepartmentList()
        {
            List<Departmentlist> data = da.DepartmentList();
            if (data != null)
            {
                displayMessage.response = "Success";
                displayMessage.error = "";
                displayMessage.message = "";
                displayMessage.result = data;
                return Ok(displayMessage);
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "No Record Found";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
        /// <summary>
        /// Get All Department Admin List
        /// </summary>
        /// <remarks>
        /// You Get the all AdminList
        /// </remarks>
        /// <returns></returns>
        [Route("AdminList")]
        public IHttpActionResult GetAdminList()
        {
            List<AdminList> data = da.AdminList();
            if (data != null)
            {
                displayMessage.response = "Success";
                displayMessage.error = "";
                displayMessage.message = "";
                displayMessage.result = data;
                return Ok(displayMessage);
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "No Record Found";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
        /// <summary>
        /// Get Department Login Info by Department Id
        /// </summary>
        /// <remarks>
        /// ADepartment Id is Required
        /// </remarks>
        /// <param name="dptId">
        /// Submit The Department Id
        /// </param>
        /// <returns></returns>
        [Route("LoginInfo/{dptId}")]
        public IHttpActionResult GetDepartmentById(string dptId)
        {
            Departmentlist data = da.GetDepartmentById(dptId);
            if (data != null)
            {
                displayMessage.response = "Success";
                displayMessage.error = "";
                displayMessage.message = "";
                displayMessage.result = data;
                return Ok(displayMessage);
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "No Record Found";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
        /// <summary>
        /// Get DBConfig Info by Department Id
        /// </summary>
        /// <remarks>
        /// Submit Department Id To Get Database Config
        /// </remarks>
        /// <param name="dptId">
        /// Submit Department Id
        /// </param>
        /// <returns></returns>
        [Route("DBConfig/{dptId}")]
        public IHttpActionResult GetDBConfig(string dptId)
        {
            DbConfig data = da.DbConfigById(dptId);
            if (data != null)
            {
                displayMessage.response = "Success";
                displayMessage.error = "";
                displayMessage.message = "";
                displayMessage.result = data;
                return Ok(displayMessage);
            }
            else
            {
                displayMessage.response = "Fail";
                displayMessage.error = "No Record Found";
                displayMessage.message = "";
                displayMessage.result = new { };
                return Content(HttpStatusCode.BadRequest, displayMessage);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MBoardapp.Models
{
    public class SuperAdminModel
    {
        [Required(AllowEmptyStrings = false)]
        public string UserName { get; set; }
        [Required(AllowEmptyStrings = false)]

        public string Password { get; set; }
        [Required(AllowEmptyStrings = false)]

        public string Captcha { get; set; }

    }
    public class SuperAdminAfterLoginModel
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

    }
    public class SuperAdminProfileData
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public DateTime? Lastlogin { get; set; }
        public string ProfilePic { get; set; }
        public string UserName { get; set; }
    }
    public class AddDepartmentModel
    {
        public string DepartmentName { get; set; }
        public string Title { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Logo { get; set; }
        public string DepartmentId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

    }
    public class DepartmentDataAfterAdd
    {
        public string DepartmentId { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
    }
    public class Departmentlist
    {
        public int Id { get; set; }
        public string DepartmentName { get; set; }
        public string Title { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Logo { get; set; }
        public string DepartmentId { get; set; }

    }
    public class AdminList
    {
        public Int64 UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int DeptId { get; set; }
        public int Roll { get; set; }
        public int GroupId { get; set; }
        public string Mobile { get; set; }
        public string ProfilePic { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsFirstLogin { get; set; }
        public string LastLoginIP { get; set; }
        public string OTP { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastChnagePassword { get; set; }
        public int Designation { get; set; }
        public string Email { get; set; }

    }
    public class DbConfig
    {
        public int Id { get; set; }
        public string ServerIP { get; set; }
        public string DBName { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public string DptId { get; set; }

    }
}
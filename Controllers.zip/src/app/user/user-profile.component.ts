
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from '../common/custom-validators';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styles: []
})
export class UserProfileComponent implements OnInit {
  OldPass: any;
  divprofile = true;
  divpass = true;
  imageUrl: string = "/assets/img/default.png";
  defaultPic: string;
  fileToUpload: File = null;
  profileinfo: any = {};

  username: string = "";
  mobileno: string = "";
  isreset: boolean;

  decrypt = localStorage.getItem("userToken").toString();
  userId = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  OldPassincorrect: boolean = false;
  public frmSignup: FormGroup;

  baseurl: any = "";
  constructor(private service: MailboxserviceService, private toastr: ToastrService, private router: Router, private fb: FormBuilder) {
    this.frmSignup = this.createSignupForm();
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {


    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.profileinfo = k;
      this.mobileno = k['mobileNo'];
      this.username = k['officeName'];

      if (k['profilePic'] != null) {
        this.defaultPic = this.baseurl + '/UserProfile/' + k['profilePic'];
      }
    });
    this.divprofile = true;
    this.divpass = true;
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  profileUpdate(mobileNo, ProfilePic) {
    this.service.UpdateProfile(mobileNo.value, this.fileToUpload, this.userId).subscribe(
      data => {
        this.toastr.success('Profile Updated!', 'Success');
        this.defaultPic = this.baseurl + '/UserProfile/' + data['profilePic'];
        this.profileinfo = data;
        ProfilePic.value = null;
        this.imageUrl = "/assets/img/default.png";
        this.divprofile = true;
        this.divpass = true;
        this.isreset = true;
      }
    );
  }

  handleFileInput(file: FileList) {
    this.service.PicHandle(file.item(0)).subscribe(
      data => {
        this.fileToUpload = file.item(0);
        var reader = new FileReader();
        this.isreset = false;
        reader.onload = (event: any) => {
          this.imageUrl = event.target.result;
        }
        reader.readAsDataURL(this.fileToUpload);
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.isreset = true;
          Swal.fire({
            icon: 'warning',
            title: err.error.message,
            text: "Warning",
          })
        };
      }
    );
  }

  changeUserPassword(userId) {
    const password = this.frmSignup.get('password');
    this.service.changePassword(userId, password.value).subscribe(
      data => {
        this.toastr.success('', 'Password Changed Successfully');
        this.divprofile = true;
        this.divpass = true;
      }
    );
  }
  onChange(userId) {
    const OldPass = this.frmSignup.get('OldPass');
    this.service.CheckOldPass(userId, OldPass.value).subscribe((data: any) => {
      if (data == "success") {
        this.OldPassincorrect = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.OldPassincorrect = true;

        // Swal.fire({
        //   icon: 'warning',
        //   title: err.error.message,
        //   text: "Warning",
        //   confirmButtonColor: '#3085d6',
        //   confirmButtonText: 'ok Try Again!'
        // }).then((result) => {
        //   if (result.value) {
        //     this.OldPassincorrect = true;
        //   }
        // })
      };
    });
  }

  profile() {
    this.divprofile = false;
    this.divpass = true;
  }
  password() {
    this.divprofile = true;
    this.divpass = false;
  }
  close() {
    this.ngOnInit();
    this.OldPassincorrect = false;
    fileToUpload: File = null;
    this.isreset = true;
    this.imageUrl = "/assets/img/default.png";
  }
  //******************** */
  createSignupForm(): FormGroup {
    return this.fb.group(
      {
        OldPass: [
          null,
          Validators.compose([Validators.required])
        ],
        password: [
          null,
          Validators.compose([
            Validators.required,
            CustomValidators.patternValidator(/\d/, {
              hasNumber: true
            }),
            CustomValidators.patternValidator(/[A-Z]/, {
              hasCapitalCase: true
            }),
            CustomValidators.patternValidator(/[a-z]/, {
              hasSmallCase: true
            }),
            CustomValidators.patternValidator(
              /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
              {
                hasSpecialCharacters: true
              }
            ),
            Validators.minLength(8)
          ])
        ],
        confirmPassword: [null, Validators.compose([Validators.required])],
        userId: []
      },
      {
        validator: CustomValidators.passwordMatchValidator
      }
    );
  }
  reset() {
    this.OldPassincorrect = false;
    fileToUpload: File = null;
    this.isreset = true;

  }
  resetprofile() {
    this.ngOnInit();
    this.divprofile = false;
    this.divpass = true;
    this.imageUrl = "/assets/img/default.png";
    this.fileToUpload = null;
    this.isreset = true;
  }
}


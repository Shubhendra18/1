import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
declare let $: any;


@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styles: []
})
export class UserNavbarComponent implements OnInit, AfterViewInit {
  @ViewChild('openModal', { static: true }) openModal: ElementRef;

  decrypt = localStorage.getItem("userToken").toString();
  userId = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  userName = "";
  isFoo: boolean = false;

  isimportant = "text-dark";
  broadcastmsg: any = [];
  broadcastmsgSingle: any = [];

  brodhide = true;
  broadcastpic = "";
  profilepic = "";
  baseurl: any = "";
  broadcastlength = "";
  constructor(private router: Router, private service: MailboxserviceService) {
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {

    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.userName = k['officeName'];
    });
    this.service.BroadcastGet(this.userId).subscribe(k => {
      if (k != null) {
        this.broadcastmsg = k;
      }
    });
  }
  ngAfterViewInit() {
    $.getScript('assets/js/mycutometoggle.js');
    //$.getScript('assets/js/nifty.min.js');
  }
 
  openbroadcast(rowId) {
    this.broadcastmsgSingle = this.broadcastmsg.filter(x => x.rowId === rowId);
    this.brodhide = false;
  }
  broadcastseen(rowId) {
    this.service.MarkBroadcastSeen(rowId).subscribe(k => {
      this.ngOnInit();
    });
  }
  Logout() {
    localStorage.removeItem('userToken');
    localStorage.removeItem('seen');

    this.router.navigate(['/login']);
  }
}
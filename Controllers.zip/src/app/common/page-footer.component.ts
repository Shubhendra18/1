import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './page-footer.component.html',
  styles: []
})
export class PageFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

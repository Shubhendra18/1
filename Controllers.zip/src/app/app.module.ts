import { BrowserModule } from '@angular/platform-browser';
import { NgModule, enableProdMode } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { DataTablesModule } from 'angular-datatables';
import { AvatarModule } from 'ngx-avatar';
const avatarColors = ["rgb(224, 40, 67)", "#212e77", "#237177", "#e79105", "#5d9208"];
import { NgxPaginationModule } from 'ngx-pagination';
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';

import { UserNavbarComponent } from './user/user-navbar.component';
import { UserSidebarComponent } from './user/user-sidebar.component';
import { UserInboxComponent } from './user/user-inbox.component';
import { UserComposeComponent } from './user/user-compose.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { HttpClientModule } from '@angular/common/http';
import { UserLoginComponent } from './user/user-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { MailboxserviceService } from './mailboxservice.service';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserlistComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminprofileComponent } from './admin/admin-profile.component';
import { AdminSidebarComponent } from './admin/admin-sidebar.component';
import { AdminNavbarComponent } from './admin/admin-navbar.component';
import { UserInboxInfoComponent } from './user/user-inbox-info.component';
import { UserSendComponent } from './user/user-send.component';
import { UserImportantComponent } from './user/user-important.component';
import { UserDraftComponent } from './user/user-draft.component';
import { UserDraftComposeComponent } from './user/user-draft-compose.component';
import { UserArchiveComponent } from './user/user-archive.component';
import { UserTrashComponent } from './user/user-trash.component';
import { UserForgetComponent } from './user/user-forget.component';
import { PageHeadComponent } from './common/page-head.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { UserProfileComponent } from './user/user-profile.component';
import { SentmailDesComponent } from './user/sentmail-des.component';
import { ErrorpageComponent } from './common/errorpage.component';
import { AdminmailboxComponent } from './admin/adminmailbox.component';
import { AdminmailboxinfoComponent } from './admin/adminmailboxinfo.component';
import { AdmincreateComponent } from './admin/admincreate.component';
import { AdminsentmailComponent } from './admin/adminsentmail.component';
import { AdminsentdetailsComponent } from './admin/adminsentdetails.component';
import { AdminimportantComponent } from './admin/adminimportant.component';
import { AdmindraftComponent } from './admin/admindraft.component';
import { AdmindraftcomComponent } from './admin/admindraftcom.component';
import { AdminarchiveComponent } from './admin/adminarchive.component';
import { AdminartrashComponent } from './admin/adminartrash.component';
import { CookieService } from 'ngx-cookie-service';
import { AuthGuard } from './gaurds/auth.guard';
import { AdminauthGuard } from './gaurds/adminauth.guard';
import { DragDropDirective } from './DragDropDirective ';
import { AppPasswordDirective } from './common/app-password.directive';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { BroadcaststatsComponent } from './admin/broadcaststats.component';
import { GetsendreclistComponent } from './admin/getsendreclist.component';
import { WebcamModule } from 'ngx-webcam';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ForwordComponent } from './user/forword.component';
import { AdminforwardComponent } from './admin/adminforward.component';
import { NoRightClickDirective } from './norightclick';
import { PageFooterComponent } from './common/page-footer.component';
import { UseractiveComponent } from './admin/useractive.component';
import { UserinactiveComponent } from './admin/userinactive.component';
import { DptlandingComponent } from './landing/dptlanding/dptlanding.component';
import { AdddepartmentComponent } from './superadmin/adddepartment.component';
import { SuperadminloginComponent } from './superadmin/superadminlogin.component';
import { SdahboardComponent } from './superadmin/sdahboard.component';
import { SasidebarComponent } from './superadmin/sasidebar.component';
import { SanavbarComponent } from './superadmin/sanavbar.component';
import { DptselectorComponent } from './landing/dptselector/dptselector.component';
import { DepartmentlistComponent } from './superadmin/departmentlist.component';
import { SuperadminprofileComponent } from './superadmin/superadminprofile.component';
import { SuperpageheadComponent } from './superadmin/superpagehead.component';
import { ManageadminComponent } from './superadmin/manageadmin.component';
enableProdMode();
@NgModule({
  declarations: [
    AppComponent,
    DragDropDirective,
    UserNavbarComponent,
    UserSidebarComponent,
    UserInboxComponent,
    PageFooterComponent,
    UserComposeComponent,
    UserLoginComponent,
    AdminLoginComponent,
    AdminDashboardComponent,
    ManageGroupComponent,
    ManageUserComponent,
    UserlistComponent,
    ResetPassComponent,
    BroadcastComponent,
    SendReceivestatsComponent,
    UsernotusingmboardComponent,
    LastloginComponent,
    MsgReportComponent,
    AdminprofileComponent,
    AdminSidebarComponent,
    AdminNavbarComponent,
    UserInboxInfoComponent,
    UserSendComponent,
    UserImportantComponent,
    UserDraftComponent,
    UserDraftComposeComponent,
    UserArchiveComponent,
    UserTrashComponent,
    UserForgetComponent,
    PageHeadComponent,
    UserProfileComponent,
    SentmailDesComponent,
    ErrorpageComponent,
    AdminmailboxComponent,
    AdminmailboxinfoComponent,
    AdmincreateComponent,
    AdminsentmailComponent,
    AdminsentdetailsComponent,
    AdminimportantComponent,
    AdmindraftComponent,
    AdmindraftcomComponent,
    AdminarchiveComponent,
    AdminartrashComponent,
    AppPasswordDirective,
    BroadcaststatsComponent,
    GetsendreclistComponent,
    ForwordComponent,
    AdminforwardComponent,
    NoRightClickDirective,
    UseractiveComponent,
    UserinactiveComponent,
    DptlandingComponent,
    AdddepartmentComponent,
    SuperadminloginComponent,
    SdahboardComponent,
    SasidebarComponent,
    SanavbarComponent,
    DptselectorComponent,
    DepartmentlistComponent,
    SuperadminprofileComponent,
    SuperpageheadComponent,
    ManageadminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSummernoteModule,
    HttpClientModule,
    NgMultiSelectDropDownModule.forRoot(),
    CommonModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      closeButton: true,
      progressBar: true,
      progressAnimation: 'decreasing',
      positionClass: 'toast-top-center',
      timeOut: 2000,
      preventDuplicates: true,
    }),
    DataTablesModule,
    AvatarModule.forRoot({
      colors: avatarColors
    }),
    NgxPaginationModule,
    Ng2SearchPipeModule,
    NgDatepickerModule,
    WebcamModule,
    ServiceWorkerModule.register('./ngsw-worker.js', { enabled: environment.production }),
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.doubleBounce,
      backdropBorderRadius: '4px',
      primaryColour: '#25476a',
      secondaryColour: '#25476a',
      tertiaryColour: '#25476a',
      fullScreenBackdrop: true
    }),
  ],
  providers: [MailboxserviceService, CookieService, AuthGuard, AdminauthGuard, { provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-adminartrash',
  templateUrl: './adminartrash.component.html',
  styles: []
})
export class AdminartrashComponent implements OnInit {
  SData: any;
  p: number = 1;

  allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  baseurl: any = "";
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();

  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromTrash(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }

  BackToInbox(mailId) {
    var moveToInbox = { "mailId": mailId, "flag": 2 };
    this.service.backToInbox(moveToInbox).subscribe(k => {
      if (k == "success") {
        this.toastr.success('', 'Message Moved to Inbox Successfully');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }
}

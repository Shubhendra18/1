import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-userinactive',
  templateUrl: './userinactive.component.html',
  styles: []
})
export class UserinactiveComponent implements OnInit {

  usedUserData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService) { }
  ngOnInit() {
    this.service.GetNotUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
}

import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['../user/user-login.component.css']

})
export class AdminLoginComponent implements OnInit {
  captchaKey: string = "";
  captchaerror = false;
  captcha: any = "";
  baseurl: any = "";
  captchapic: any = "";
  encrpt: string;
  plainText: string;
  public loading = false;

  constructor(private service: MailboxserviceService, private router: Router) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/Admin/GetCaptcha";
  }

  ngOnInit() {
  }

  refreshcaptcha() {
    this.captchapic = this.baseurl + "/Admin/GetCaptcha?=" + Math.random();
  }

  sendlogin(loginData) {
    this.loading = true;
    this.service.AdminLogin(loginData.value).subscribe((data: any) => {
      this.plainText = data.userId.toString();
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "at").toString();
      localStorage.setItem('Token', this.encrpt);
      this.router.navigate(['/dashboard']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: err.error.message,
          text: "Warning",
        })
        this.loading = false;
        this.refreshcaptcha();
        loginData.value.Password = "";
      };
    });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { DisplayMsg } from '../models/responsemsg';

@Component({
  selector: 'app-manageadmin',
  templateUrl: './manageadmin.component.html',
  styles: []
})
export class ManageadminComponent implements OnInit {
  adminList: any = [];
  baseurl: any = "";

  constructor(private service: MailboxserviceService) {
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {
    this.service.AdminList().subscribe((data: DisplayMsg) => {
      this.adminList = data['result'];
    });
  }

}

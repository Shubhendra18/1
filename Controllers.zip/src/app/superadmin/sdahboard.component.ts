import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sdahboard',
  templateUrl: './sdahboard.component.html',
  styles: []
})
export class SdahboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

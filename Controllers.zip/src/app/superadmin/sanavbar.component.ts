import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sanavbar',
  templateUrl: './sanavbar.component.html',
  styles: []
})
export class SanavbarComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  ngAfterViewInit() {
    $.getScript('assets/js/mycutometoggle.js');
    $.getScript('assets/plugins/fooTable/dist/footable.all.min.js');
    $.getScript('assets/js/demo/tables-footable.js');
    //$.getScript('assets/js/nifty.min.js');
  }
  Logout() {
    localStorage.removeItem('SToken');
    this.router.navigate(['/administrator']);
  }
}

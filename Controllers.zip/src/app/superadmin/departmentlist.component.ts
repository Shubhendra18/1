import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { DisplayMsg } from '../models/responsemsg';

@Component({
  selector: 'app-departmentlist',
  templateUrl: './departmentlist.component.html',
  styles: []
})
export class DepartmentlistComponent implements OnInit {
  dptList: any = [];
  baseurl: any = "";

  constructor(private service: MailboxserviceService) {
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {
    this.service.DepartmentList().subscribe((data: DisplayMsg) => {
      this.dptList = data['result'];
    });
  }

}

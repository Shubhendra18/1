import { DisplayMsg } from './../../models/responsemsg';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { MailboxserviceService } from 'src/app/mailboxservice.service';

@Component({
  selector: 'app-dptselector',
  templateUrl: './dptselector.component.html',
  styleUrls: ['../../user/user-login.component.css', './dptselector.component.css']
})
export class DptselectorComponent implements OnInit {
  officeName: any;
  PasswordData: any;
  CaptchaData: any;

  defaultgroup = null;
  defaultname = null;
  groupData: any = [];
  users: any = [];
  captchaKey: string = "";
  captchaerror = false;
  encrpt: string;
  plainText: string;
  baseurl: any = "";
  captchapic: any;
  public loading = false;

  dptid: any;
  dptData: any = {};
  constructor(private service: MailboxserviceService, private toaster: ToastrService, private router: Router, private route: ActivatedRoute) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha";

  }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.dptid = params.get('dpt');
      this.service.Departmentinfo(this.dptid).subscribe(k => {
        this.dptData = k['result'];
        console.log(this.dptData)
      });
    });
  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.users = k;
    });
  }
  refreshcaptcha() {
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha?=" + Math.random();
  }

  login(loginData) {
    this.loading = true;
    this.service.AdminstratorLogin(loginData.value).subscribe((data: DisplayMsg) => {
      console.log(data);
      this.plainText = data.result['Id'];
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "st").toString();
      localStorage.setItem('SToken', this.encrpt);
      this.loading = false;
      this.router.navigate(['/Controlpanel']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: "Invalid!",
          text: err.error.error,
        })
        this.loading = false;
        this.refreshcaptcha();
        this.CaptchaData = "";
        this.PasswordData = "";
      };
    });
  }
  reset() {
    this.defaultgroup = null;
    this.defaultname = null;
    this.users = [];
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}

﻿using MBoardapp.Filters;
using MBoardapp.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MBoardapp.Repository
{
    public class SuperAdminContext : DbContext
    {
        public SuperAdminContext() : base("MboardContext")
        {

        }
        public SuperAdminAfterLoginModel SuperAdminLogin(string userName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userName",Value=userName},
                new SqlParameter {ParameterName="@lastLoginIP",Value=Common.GetIPAddress()},
                 };
            var sqlQuery = @"sp_SuperAdminLogin @userName,@lastLoginIP";
            var res = this.Database.SqlQuery<SuperAdminAfterLoginModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public SuperAdminProfileData SuperAdminProfile(int Id)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@Id",Value=Id},
                 };
            var sqlQuery = @"sp_SuperProfileInfo @Id";
            var res = this.Database.SqlQuery<SuperAdminProfileData>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public DepartmentDataAfterAdd DepartmentRegistration(AddDepartmentModel model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@name",Value=model.DepartmentName},
                new SqlParameter {ParameterName="@address",Value=model.Address},
                new SqlParameter {ParameterName="@email",Value=model.Email},
                new SqlParameter {ParameterName="@mobile",Value=model.Mobile},
                new SqlParameter {ParameterName="@logo",Value=model.Logo},
                new SqlParameter {ParameterName="@dptid",Value=model.DepartmentId},
                new SqlParameter {ParameterName="@username",Value=model.UserName},
                new SqlParameter {ParameterName="@password",Value=model.Password},
                new SqlParameter {ParameterName="@title",Value=model.Title},
                 };
            var sqlQuery = @"sp_AddDepartment @name,@address,@email,@mobile,@logo,@dptid,@username,@password,@title";
            var res = this.Database.SqlQuery<DepartmentDataAfterAdd>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<Departmentlist> DepartmentList()
        {
            var sqlQuery = @"sp_DepartmentList";
            var res = this.Database.SqlQuery<Departmentlist>(sqlQuery).ToList();
            return res;
        }
        public List<AdminList> AdminList()
        {
            var sqlQuery = @"sp_GetAllAdminList";
            var res = this.Database.SqlQuery<AdminList>(sqlQuery).ToList();
            return res;
        }
        public Departmentlist GetDepartmentById(string dptId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@dptId",Value=dptId},
                 };
            var sqlQuery = @"sp_GetDepartmentDetails @dptId";
            var res = this.Database.SqlQuery<Departmentlist>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public DbConfig DbConfigById(string dptId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@dptId",Value=dptId},
                 };
            var sqlQuery = @"sp_GetDBConfig @dptId";
            var res = this.Database.SqlQuery<DbConfig>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
    }
}
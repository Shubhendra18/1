import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sasidebar',
  templateUrl: './sasidebar.component.html',
  styles: []
})
export class SasidebarComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  Logout() {
    localStorage.removeItem('SToken');
    this.router.navigate(['/administrator']);
  }
}

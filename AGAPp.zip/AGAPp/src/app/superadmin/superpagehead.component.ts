import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superpagehead',
  templateUrl: './superpagehead.component.html',
  styles: []
})
export class SuperpageheadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

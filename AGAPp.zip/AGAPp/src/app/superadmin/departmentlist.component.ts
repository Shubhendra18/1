import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { DisplayMsg } from '../models/responsemsg';
import { DatepickerOptions } from 'ng2-datepicker';
import * as enLocale from 'date-fns/locale/en';

@Component({
  selector: 'app-departmentlist',
  templateUrl: './departmentlist.component.html',
  styles: []
})
export class DepartmentlistComponent implements OnInit {
  dptList: any = [];
  singleDpt: any = [];
  baseurl: any = "";
  dptid: string;
  inedit: boolean = false;
  subedit: boolean = false;
  subcriptionStartdate: Date;
  subcriptionEnddate: Date;
  constructor(private service: MailboxserviceService, private toaster: ToastrService) {
    this.baseurl = this.service.getbaseurl();
    this.subcriptionStartdate = new Date();
    this.subcriptionEnddate = new Date();

  }

  ngOnInit() {
    this.service.DepartmentList().subscribe((data: DisplayMsg) => {
      this.dptList = data['result'];
    });
  }
  soptions: DatepickerOptions = {
    minYear: (new Date()).getFullYear(),
    displayFormat: 'MMM D[,] YYYY',
    barTitleFormat: 'MMMM YYYY',
    dayNamesFormat: 'dd',
    firstCalendarDay: 1, // 0 - Sunday, 1 - Monday
    locale: enLocale,
    minDate: new Date(Date.now()),
    placeholder: 'Subcription From'
  };
  eoptions: DatepickerOptions = {
    minYear: (new Date()).getFullYear(),
    displayFormat: 'MMM D[,] YYYY',
    barTitleFormat: 'MMMM YYYY',
    dayNamesFormat: 'dd',
    firstCalendarDay: 1, // 0 - Sunday, 1 - Monday
    locale: enLocale,
    placeholder: 'Valid Till'
  };
  dbData(id) {
    this.singleDpt = (this.dptList.filter(k => k.id == id)[0]);
    this.dptid = this.singleDpt.departmentId

  }
  SaveDBConfig(dbConfig) {
    this.service.AddDBConfig(dbConfig.value).subscribe((data: DisplayMsg) => {
      this.singleDpt = data['result'];
      this.toaster.success('', "Success");
    })
  }
  Close() {
    this.inedit = false;
    this.subedit = false;
  }
  SaveDetails(saveData) {
    this.service.UpdateDptdata(saveData.value).subscribe((data: DisplayMsg) => {
      this.singleDpt = data['result'];
      this.toaster.success('', "Success");
      this.inedit = false;
    })
  }
  UpdateSubscription(subdata) {
    this.service.UpdateSubcriptiondata(subdata.value).subscribe((data: DisplayMsg) => {
      this.singleDpt = data['result'];
      this.toaster.success('', "Success");
      this.subedit = false;
    })
  }
  SecondDate(subcriptionStartdate) {
    this.subcriptionEnddate = subcriptionStartdate
    this.eoptions.minDate = subcriptionStartdate;
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}

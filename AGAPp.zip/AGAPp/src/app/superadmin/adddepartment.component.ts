import { DisplayMsg } from './../models/responsemsg';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { DatepickerOptions } from 'ng2-datepicker';
import * as enLocale from 'date-fns/locale/en';


@Component({
  selector: 'app-adddepartment',
  templateUrl: './adddepartment.component.html',
  styles: []
})
export class AdddepartmentComponent implements OnInit {
  files: File[] = [];
  fileToUpload: File = null;
  ishasfile: any;
  Sedate: Date;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.Sedate = new Date();
  }
  ngOnInit() {

  }
  options: DatepickerOptions = {
    minYear: (new Date()).getFullYear(),
    displayFormat: 'MMM D[,] YYYY',
    barTitleFormat: 'MMMM YYYY',
    dayNamesFormat: 'dd',
    firstCalendarDay: 1, // 0 - Sunday, 1 - Monday
    locale: enLocale,
    minDate: new Date(Date.now()),
    placeholder: 'Select Till Date'
  };

  sendBroadcast(dptdata) {
    this.service.AddDepartment(dptdata.value.dptName, dptdata.value.title, dptdata.value.address, dptdata.value.email, dptdata.value.mobileNo, this.fileToUpload, dptdata.value.Sedate, dptdata.value.maxuser).subscribe((data: DisplayMsg) => {
      if (data.response == "Success") {
        Swal.fire({
          icon: 'success',
          title: 'Created',
          text: data.message,
        })
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.toastr.error('Something went wrong', 'Error');
      };
    });

  }
  handleFileInput(file: FileList) {
    this.service.PicHandle(file.item(0)).subscribe(
      data => {
        this.fileToUpload = file.item(0);
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          Swal.fire({
            icon: 'warning',
            title: err.error.message,
            text: "Warning",
          })
        };
      }
    );
    
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}

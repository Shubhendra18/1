import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-lastlogin',
  templateUrl: './lastlogin.component.html',
  styles: []
})
export class LastloginComponent implements OnInit {
  loginrptData: any = [];
  dtOptions: DataTables.Settings = {

  };
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService) { }

  ngOnInit() {
    this.service.GetLastLogin().subscribe(k => {
      this.loginrptData = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

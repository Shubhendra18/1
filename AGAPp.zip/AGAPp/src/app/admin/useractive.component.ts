import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-useractive',
  templateUrl: './useractive.component.html',
  styles: []
})
export class UseractiveComponent implements OnInit {
  usedUserData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService) { }
  ngOnInit() {
    this.service.GetUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
}


import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import { HttpErrorResponse } from '@angular/common/http';
declare var $;

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styles: []
})
export class UserlistComponent implements OnInit, OnDestroy {
  manageUserList: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  updateUserName: string = "";
  updateUserMobile: string = "";
  updateUserid: string = "";

  message = 'false';
  isActive: boolean = true;
  checkbox: boolean;
  public show: boolean = false;
  public buttonName: any = 'Show';
  public loading = false;
  values = '';
  mobilealreadytaken: boolean = false;
  alreadytaken: boolean = false;

  constructor(private service: MailboxserviceService, private toaster: ToastrService) { }

  ngOnInit() {
    this.service.GetGroupUserForManage(0).subscribe(k => {
      this.manageUserList = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'lfrtip', paging: true

    };
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByFn(index: number, item) {
    return index;
  }
  tosendUpdate(k) {
    this.updateUserName = k.officeName;
    this.updateUserMobile = k.mobileNo;
    this.updateUserid = k.userId;
  }
  ManageUserMaster(ManageUserData) {
    this.service.updateUserMaster(ManageUserData.value).subscribe(k => {
      if (k == 'Success') {
        this.toaster.success('', 'User Details Updated Successfully');
        $("#userEdit").modal('hide');
        this.service.GetGroupUserForManage(0).subscribe(k => {
          this.manageUserList = k;
        });
      }
      else {
        this.toaster.error('Failed to Updated', 'Error');
      }
    });

  }

  actdeact(userId, recflag) {
    this.loading = true;

    var activeDeactive = { 'recflag': recflag, 'userId': userId };
    this.service.ActiveDeactiveUser(activeDeactive).subscribe(k => {
      this.service.GetGroupUserForManage(0).subscribe(k => {
        this.manageUserList = k;
        this.loading = false;

      });
    });
  }
  onChange(event: any) {
    this.values = event.target.value;
    var userorMobile = { 'userorMobile': this.values, 'flag': '0' };
    this.service.chkNameorMobile(userorMobile).subscribe((data: any) => {
      if (data === "Success") {
        this.alreadytaken = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.alreadytaken = true;
      };
    });
  }
  onMobileChange(event: any) {
    this.values = event.target.value;
    var userorMobile = { 'userorMobile': this.values, 'flag': '1' };
    this.service.chkNameorMobile(userorMobile).subscribe((data: any) => {
      if (data === "Success") {
        this.mobilealreadytaken = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.mobilealreadytaken = true;
      };
    });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  Close() {
    this.mobilealreadytaken = false;
    this.alreadytaken = false;
  }
}

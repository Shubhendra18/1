import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import { NgxSpinnerService } from 'ngx-spinner';
import { DisplayMsg } from '../models/responsemsg';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['../user/user-login.component.css']

})
export class AdminLoginComponent implements OnInit {
  captchaKey: string = "";
  captchaerror = false;
  captcha: any = "";
  baseurl: any = "";
  captchapic: any = "";
  encrpt: string;
  plainText: string;
  public loading = false;
  dptid: any;
  dptData: any = {};

  constructor(private service: MailboxserviceService, private router: Router, private route: ActivatedRoute, private SpinnerService: NgxSpinnerService) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha";
  }

  ngOnInit() {
    this.GetData();
  }
  GetData() {
    this.SpinnerService.show();
    this.route.paramMap.subscribe(params => {
      this.dptid = params.get('dpt');
      this.service.Departmentinfo(this.dptid).subscribe(k => {
        this.dptData = k['result'];
        this.SpinnerService.hide();
      });
      this.service.DBConfigData(this.dptid).subscribe();
    });
  }
  refreshcaptcha() {
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha?=" + Math.random();
  }

  sendlogin(loginData) {
    this.loading = true;
    this.service.AdminLogin(loginData.value).subscribe((data: DisplayMsg) => {
      this.plainText = data.result['userId'].toString();
      console.log(this.plainText)
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "at").toString();
      localStorage.setItem('Token', this.encrpt);
      localStorage.setItem('Dep', this.dptid);
      this.loading = false;
      this.router.navigate(['/dashboard']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: "Invalid!",
          text: err.error.error,
        })
        this.loading = false;
        this.refreshcaptcha();
        loginData.value.Password = "";
      };
    });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
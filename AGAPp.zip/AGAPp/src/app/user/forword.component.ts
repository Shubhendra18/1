import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { MailboxserviceService } from '../mailboxservice.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { Location } from '@angular/common';
declare var $;
@Component({
  selector: 'app-forword',
  templateUrl: './forword.component.html',
  styles: []
})
export class ForwordComponent implements OnInit {
  defaultgroup = null;
  defaultname = null;

  groupData: any = [];
  public users: any = [];

  decrypt = localStorage.getItem("userToken").toString();
  Sid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  dropdownList: any = [];
  selectedItems = [];
  dropdownSettings = {};
  files: File[] = [];
  rId: any[] = [];
  maildetails: any = {};

  mailattach: any;
  filetosend: any = [];
  current: any = [];
  constructor(private service: MailboxserviceService, private toastr: ToastrService, private route: ActivatedRoute, private _location: Location) { }

  ngOnInit() {


    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });

    this.route.paramMap.subscribe(params => {
      var mailDes = { "mailId": params.get('fml'), "rid": this.Sid };
      this.service.getforword(mailDes).subscribe(k => {
        this.maildetails = k;
        this.mailattach = k['attachment'];
        var atchdata = (this.mailattach.split(','))
        for (let index = 0; index < this.mailattach.split(',').length; index++) {
          this.filetosend.push(this.mailattach.split(',')[index])
        }
      })
    });
    this.dropdownSettings = {
      singleSelection: false,
      data: 'dropdownList',
      idField: 'userId',
      textField: 'officeName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.current = k;
      let userid = this.Sid;
      this.dropdownList = this.current.filter(function (x) { return x['userId'] != userid });
    });

  }


  omattachdelete(index) {
    this.filetosend.splice(index, 1)
  }

  onItemSelect(item: any) {
    this.rId.push(item)
  }
  onSelectAll(items: any) {
    for (let index = 0; index < items.length; index++) {
      const element = items[index];
      this.rId.push(element)
    }
  }
  onItemDeSelect(item: any) {
    this.rId.splice(item);
  }

  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      this.service.FileHandle(element).subscribe(
        data => {
          this.files.push(element);
        }, (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              icon: 'warning',
              title: err.error.message,
              text: "Warning",
            })
          };
        }
      );
    }
  }

  deleteAttachment(index) {
    this.files.splice(index, 1)
  }
  ForwardMsg(mailBox) {
    this.service.ForwarMailWithfiles(this.files, mailBox.value.Priority, false, mailBox.value.Subject, mailBox.value.Message, this.Sid, mailBox.value.Rid, this.filetosend).subscribe((data: any) => {
      if (data == "success") {
        this.toastr.success('', 'Message Forwarded Successfully.');
        this.files.length = 0;
        this.rId.length = 0;
        this.filetosend.length = 0;
        this.dropdownList = [];

      }
    }, (err: HttpErrorResponse) => {
      if (err.status == 400) {
        this.toastr.error('Something went wrong', 'Error');
      };
    });;
  }
  reset() {
    this.files.length = 0;
    this.rId.length = 0;
    this.dropdownList = [];
  }
  backClicked() {
    this._location.back();
  }
}

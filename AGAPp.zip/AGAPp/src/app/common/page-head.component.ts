import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-page-head',
  templateUrl: './page-head.component.html',
  styles: []
})
export class PageHeadComponent implements OnInit {
  lastlogin: any;
  dptid: any;
  dptData: any = {};
  baseurl: any = "";

  constructor(private service: MailboxserviceService, private SpinnerService: NgxSpinnerService) {
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {
    this.GetData();
  }
  GetData() {
    this.SpinnerService.show();
    this.dptid = localStorage.getItem("Dep").toString();
    this.service.Departmentinfo(this.dptid).subscribe(k => {
      this.dptData = k['result'];
      this.SpinnerService.hide();
    });
  }
}

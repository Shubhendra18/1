import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-errorpage',
  templateUrl: './errorpage.component.html',
  styles: []
})
export class ErrorpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

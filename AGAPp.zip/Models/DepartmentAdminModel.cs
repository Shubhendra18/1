﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MBoardapp.Models
{
    public class DisplayMessage
    {
        public string response { get; set; }
        public string error { get; set; }
        public string message { get; set; }
        public object result { get; set; }
    }
    public class UserLogin
    {
        public string officeName { get; set; }
        public string Password { get; set; }
        public string Captcha { get; set; }
    }
    public class UserList
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
    public class AfterUserLogin
    {
        public Int64 userId { get; set; }
        public string officeName { get; set; }
        public int groupID { get; set; }
        public string Mandi { get; set; }
        public Int64? MandiID { get; set; }
        public DateTime LastLogin { get; set; }
        public string password { get; set; }
        public string recflag { get; set; }
    }
    public class GroupMaster
    {
        public int groupId { get; set; }
        public string groupName { get; set; }
        public bool? isDeleted { get; set; }
        public string transDate { get; set; }
        public int userId { get; set; }
        public int GroupOrder { get; set; }
        public int userCount { get; set; }
    }
    public class AddUpdateUserMaster
    {
        [Required]
        public string groupName { get; set; }
        public int userId { get; set; }
        public int transId { get; set; }


    }
    public class AddUser
    {
        [Required]
        public string officeName { get; set; }
        public string password { get; set; }
        [Required]
        public string mobileNo { get; set; }
        [Required]
        public int groupID { get; set; }
        public string recflag { get; set; }


    }
    public class UserByGroup
    {

        public Int64 userId { get; set; }
        public string officeName { get; set; }
        public int groupID { get; set; }
        public string groupName { get; set; }
        public string MobileNo { get; set; }
        public string recflag { get; set; }
        public string ActivateDeactivate { get; set; }



    }
    public class MailBox
    {
        public Int64 MailId { get; set; }
        public Int64 Sid { get; set; }
        public List<Int64> Rid { get; set; }
        public int Priority { get; set; }
        public bool? SMS { get; set; }
        public string Subject { get; set; }
        [System.Web.Mvc.AllowHtml]
        public string Message { get; set; }
        public DateTime PostDate { get; set; } = DateTime.Now;
        public bool? IsViewed { get; set; } = false;
        public bool? IsArchived { get; set; } = false;
        public bool? IsImportant { get; set; } = false;
        public bool? IsDraft { get; set; } = false;
        public bool? IsTrash { get; set; } = false;
    }
    public class LastLoginModel
    {
        public string officeName { get; set; }
        public string groupName { get; set; }
        public int groupId { get; set; }
        public DateTime LastLogin { get; set; }

    }
    public class SendAndReceiveModel
    {
        public Int64 userId { get; set; }
        public string officeName { get; set; }
        public string groupName { get; set; }
        public int groupId { get; set; }
        public int cn1 { get; set; }
        public int cn2 { get; set; }


    }
    public class UsedUser
    {
        public Int64 SN { get; set; }
        public string officeName { get; set; }
        public string groupName { get; set; }
        public string mobileNo { get; set; }
    }
    public class PostedMessageModel
    {
        public int ID { get; set; }
        public string postedBy { get; set; }
        public string postedTo { get; set; }
        public string description { get; set; }
        public string remark { get; set; }
        public string recflagvalue { get; set; }
        public string recflagvalueDisp { get; set; }
    }
    public class ActiveDeactive
    {
        public string recflag { get; set; }
        public Int64 userId { get; set; }
    }
    public class ActiveDeactiveRespnse
    {
        public string mobileNo { get; set; }
        public string status { get; set; }
        public string type { get; set; }

    }
    public class GetOfficeName
    {
        public Int64 userId { get; set; }
        public string officeName { get; set; }

    }
    public class ReportByOfficeName
    {
        public Int64 MailId { get; set; }
        public string officeName { get; set; }
        public string receiver { get; set; } = "";
        public string Subject { get; set; }
        public string Message { get; set; }
        public DateTime? PostDate { get; set; } = null;
        public bool? IsViewed { get; set; }
        public DateTime? ViewDate { get; set; } = null;
    }
    public class ReportByDate
    {
        public DateTime? sdate { get; set; } = null;
        public DateTime? edate { get; set; } = null;

    }
    public class BroadCast
    {
        public Int64 Sid { get; set; }
        [Required]
        public List<Reciver> Rid { get; set; }
        public string BrodId { get; set; }
        [Required]
        public string Message { get; set; }
        [Required]
        public string Subject { get; set; }
        public DateTime PostDate { get; set; }
        public string ThumbnailPic { get; set; } = "";
        [Required]
        public string ClosedDate { get; set; }


    }
    public class BroadCastMessage
    {
        public Int64 RowId { get; set; }
        public Int64 Sid { get; set; }
        public Int64 Rid { get; set; }
        public string BrodId { get; set; }
        public string Message { get; set; }
        public string Subject { get; set; }

        public DateTime PostDate { get; set; }
        public bool? IsSeen { get; set; }
        public string ThumbnailPic { get; set; } = "";

    }
    public class BroadCastMessageReport
    {
        public Int64 RowId { get; set; }
        public string groupName { get; set; }
        public string officeName { get; set; }
        public string Subject { get; set; }
        public DateTime? PostDate { get; set; }
        public DateTime? ViewDate { get; set; }
        public string Message { get; set; }
        public string ThumbnailPic { get; set; } = null;

    }
    public class Reciver
    {
        public int userId { get; set; }
        public string officeName { get; set; }

    }
    public class GetSendMessage
    {
        public Int64 userId { get; set; }
        public string flag { get; set; }

    }
    public class GetSendMessageList
    {

        public Int64 MailId { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public string postedto { get; set; }
        public DateTime? PostDate { get; set; }
        public DateTime? ViewDate { get; set; }
        public string Attachment { get; set; } = null;

    }
    public class ChkUserMobile
    {
        public string UserorMobile { get; set; }
        public string flag { get; set; }
    }

}
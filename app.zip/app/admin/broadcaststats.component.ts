import { Component, OnInit, OnDestroy } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-broadcaststats',
  templateUrl: './broadcaststats.component.html',
  styles: []
})
export class BroadcaststatsComponent implements OnInit, OnDestroy {
  bradocastrpt: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  bradoDes: any = [];
  baseurl: any = "";

  constructor(private service: MailboxserviceService) {
    this.baseurl = this.service.getbaseurl();

  }
  ngOnInit() {
    this.service.GetBroadcastReport().subscribe(k => {
      this.bradocastrpt = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'lfrtip', paging: true
    };
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  BroadcastDetails(rowId) {
    this.bradoDes = (this.bradocastrpt.filter(k => k.rowId == rowId));
  }
}

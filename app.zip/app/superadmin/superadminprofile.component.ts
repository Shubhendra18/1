import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superadminprofile',
  templateUrl: './superadminprofile.component.html',
  styles: []
})
export class SuperadminprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

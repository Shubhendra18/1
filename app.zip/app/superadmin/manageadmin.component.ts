import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { DisplayMsg } from '../models/responsemsg';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-manageadmin',
  templateUrl: './manageadmin.component.html',
  styles: []
})
export class ManageadminComponent implements OnInit {
  adminList: any = [];
  baseurl: any = "";
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  singleAdmin: any = [];

  constructor(private service: MailboxserviceService) {
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {
    this.service.AdminList().subscribe((data: DisplayMsg) => {
      this.adminList = data['result'];
      this.dtTrigger.next();
    });
  }
  adminData(userId) {
    this.singleAdmin = (this.adminList.filter(k => k.userId == userId)[0]);
  }
  actdeact() {

  }
}

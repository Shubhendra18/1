import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { MailboxserviceService } from '../mailboxservice.service';
import { DisplayMsg } from '../models/responsemsg';

@Component({
  selector: 'app-superadminlogin',
  templateUrl: './superadminlogin.component.html',
  styleUrls: ['../user/user-login.component.css', './superadmin.css']
})
export class SuperadminloginComponent implements OnInit {
  officeName: any;
  PasswordData: any;
  CaptchaData: any;

  defaultgroup = null;
  defaultname = null;
  groupData: any = [];
  users: any = [];
  captchaKey: string = "";
  captchaerror = false;
  encrpt: string;
  plainText: string;
  baseurl: any = "";
  captchapic: any;
  public loading = false;
  constructor(private service: MailboxserviceService, private toaster: ToastrService, private router: Router) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha";

  }

  ngOnInit() {

  }
 
  refreshcaptcha() {
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha?=" + Math.random();
  }

  login(loginData) {
    this.loading = true;
    this.service.AdminstratorLogin(loginData.value).subscribe((data: DisplayMsg) => {
      this.plainText = data.result['Id'];
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "st").toString();
      localStorage.setItem('SToken', this.encrpt);
      this.loading = false;
      this.router.navigate(['/Controlpanel']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: "Invalid!",
          text: err.error.error,
        })
        this.loading = false;
        this.refreshcaptcha();
        this.CaptchaData = "";
        this.PasswordData = "";
      };
    });
  }
  reset() {
    this.defaultgroup = null;
    this.defaultname = null;
    this.users = [];
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}

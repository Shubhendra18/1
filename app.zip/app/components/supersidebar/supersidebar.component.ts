import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supersidebar',
  templateUrl: './supersidebar.component.html',
  styles: []
})
export class SupersidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

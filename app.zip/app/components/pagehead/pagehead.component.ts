import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MailboxserviceService } from 'src/app/mailboxservice.service';

@Component({
  selector: 'app-pagehead',
  templateUrl: './pagehead.component.html',
  styles: []
})
export class PageHeadComponent implements OnInit {
  lastlogin: any;
  dptid: any;
  dptData: any = {};
  baseurl: any = "";

  constructor(private service: MailboxserviceService, private SpinnerService: NgxSpinnerService) {
    this.baseurl = this.service.getbaseurl();
  }

  ngOnInit() {
    this.GetData();
  }
  GetData() {
    this.SpinnerService.show();
    this.dptid = localStorage.getItem("Dep").toString();
    this.service.Departmentinfo(this.dptid).subscribe(k => {
      this.dptData = k['result'];
      this.SpinnerService.hide();
    });
  }
}

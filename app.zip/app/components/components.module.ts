import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { PageHeadComponent } from './pagehead/pagehead.component';
import { SupersidebarComponent } from './supersidebar/supersidebar.component';
import { SuperheaderComponent } from './superheader/superheader.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
    ],
    declarations: [
        FooterComponent,
        HeaderComponent,
        SidebarComponent,
        PageHeadComponent,
        SupersidebarComponent,
        SuperheaderComponent
    ],
    exports: [
        FooterComponent,
        HeaderComponent,
        SidebarComponent,
        PageHeadComponent,
        SupersidebarComponent,
        SuperheaderComponent

    ]
})
export class ComponentsModule { }

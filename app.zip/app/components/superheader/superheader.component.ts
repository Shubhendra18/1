import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superheader',
  templateUrl: './superheader.component.html',
  styles: []
})
export class SuperheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

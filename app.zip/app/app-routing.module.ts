import { SuperadminloginComponent } from './superadmin/superadminlogin.component';
import { AdminlayoutComponent } from './layouts/adminlayout/adminlayout.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminLoginComponent } from './admin/admin-login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserlistComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminprofileComponent } from './admin/admin-profile.component';
import { AdminmailboxComponent } from './admin/adminmailbox.component';
import { AdminmailboxinfoComponent } from './admin/adminmailboxinfo.component';
import { AdmincreateComponent } from './admin/admincreate.component';
import { AdminsentmailComponent } from './admin/adminsentmail.component';
import { AdminsentdetailsComponent } from './admin/adminsentdetails.component';
import { AdminimportantComponent } from './admin/adminimportant.component';
import { AdmindraftComponent } from './admin/admindraft.component';
import { AdmindraftcomComponent } from './admin/admindraftcom.component';
import { AdminarchiveComponent } from './admin/adminarchive.component';
import { AdminartrashComponent } from './admin/adminartrash.component';
import { AuthGuard } from './gaurds/auth.guard';
import { AdminauthGuard } from './gaurds/adminauth.guard';
import { BroadcaststatsComponent } from './admin/broadcaststats.component';
import { GetsendreclistComponent } from './admin/getsendreclist.component';
import { AdminforwardComponent } from './admin/adminforward.component';
import { DptselectorComponent } from './landing/dptselector.component';
import { DptlandingComponent } from './landing/dptlanding.component';
import { ErrorpageComponent } from './common/errorpage.component';
import { SuperAdminlayoutComponent } from './layouts/superadminlayout/superadminlayout.component';



const routes: Routes = [
  //********************User Routes************************/
  // { path: 'inbox', component: UserInboxComponent, canActivate: [AuthGuard] },
  // { path: 'details/:ml/:ms', component: UserInboxInfoComponent, canActivate: [AuthGuard] },
  // { path: 'compose', component: UserComposeComponent, canActivate: [AuthGuard] },
  // { path: 'sent', component: UserSendComponent, canActivate: [AuthGuard] },
  // { path: 'sentDetails/:messageid', component: SentmailDesComponent, canActivate: [AuthGuard] },
  // { path: 'important', component: UserImportantComponent, canActivate: [AuthGuard] },
  // { path: 'draft', component: UserDraftComponent, canActivate: [AuthGuard] },
  // { path: 'draftcom/:mailid', component: UserDraftComposeComponent, canActivate: [AuthGuard] },
  // { path: 'archive', component: UserArchiveComponent, canActivate: [AuthGuard] },
  // { path: 'trash', component: UserTrashComponent, canActivate: [AuthGuard] },
  // { path: 'forget', component: UserForgetComponent },
  // { path: 'profile', component: UserProfileComponent, canActivate: [AuthGuard] },
  // { path: 'forword/:fml', component: ForwordComponent, canActivate: [AuthGuard] },



  //********************Admin Login*************************/
  { path: ':dpt/admin', component: AdminLoginComponent },
  { path: ':dpt', component: DptselectorComponent },
  { path: 'administrator', component: SuperadminloginComponent },
  { path: 'error', component: ErrorpageComponent },
  { path: '', component: DptlandingComponent },
  { path: '**', redirectTo: '/error', pathMatch: 'full' },
  {
    path: '',
    component: AdminlayoutComponent,
    children: [{
      path: '',
      loadChildren: './layouts/adminlayout/adminlayout.module#AdminModule'
    }]
  },
  {
    path: '',
    component: SuperAdminlayoutComponent,
    children: [{
      path: '',
      loadChildren: './layouts/superadminlayout/superadminlayout.module#SuperAdminModule'
    }]
  },
  // //********************Super Admin************************/
  // { path: 'dpt', component: DptlandingComponent },
  // { path: 'administrator', component: SuperadminloginComponent },
  // { path: 'Controlpanel', component: SdahboardComponent },
  // { path: 'addDpt', component: AdddepartmentComponent },
  // { path: 'dptList', component: DepartmentlistComponent },
  // { path: 'manageProfile', component: SuperadminprofileComponent },
  // { path: 'adminlist', component: ManageadminComponent },
  // { path: ':dpt', component: DptselectorComponent },
  // //********************Default************************/
  // { path: 'error', component: ErrorpageComponent },
  // { path: '', component: DptlandingComponent },
  // { path: '**', redirectTo: '/error', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: []
})
export class AppRoutingModule { }

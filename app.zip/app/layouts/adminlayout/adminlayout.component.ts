import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlayout',
  templateUrl: './adminlayout.component.html',
  styles: []
})
export class AdminlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

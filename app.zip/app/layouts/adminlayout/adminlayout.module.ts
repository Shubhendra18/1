import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminDashboardComponent } from '../../admin/admin-dashboard.component';
import { ManageGroupComponent } from '../../admin/manage-group.component';
import { ManageUserComponent } from '../../admin/manage-user.component';
import { UserlistComponent } from '../../admin/user-list.component';
import { ResetPassComponent } from '../../admin/reset-pass.component';
import { BroadcastComponent } from '../../admin/broadcast.component';
import { SendReceivestatsComponent } from '../../admin/send-receivestats.component';
import { UsernotusingmboardComponent } from '../../admin/usernotusingmboard.component';
import { LastloginComponent } from '../../admin/lastlogin.component';
import { MsgReportComponent } from '../../admin/msg-report.component';
import { AdminprofileComponent } from '../../admin/admin-profile.component';
import { AdminmailboxComponent } from '../../admin/adminmailbox.component';
import { AdminmailboxinfoComponent } from '../../admin/adminmailboxinfo.component';
import { AdmincreateComponent } from '../../admin/admincreate.component';
import { AdminsentmailComponent } from '../../admin/adminsentmail.component';
import { AdminsentdetailsComponent } from '../../admin/adminsentdetails.component';
import { AdminimportantComponent } from '../../admin/adminimportant.component';
import { AdmindraftComponent } from '../../admin/admindraft.component';
import { AdmindraftcomComponent } from '../../admin/admindraftcom.component';
import { AdminarchiveComponent } from '../../admin/adminarchive.component';
import { AdminartrashComponent } from '../../admin/adminartrash.component';
import { BroadcaststatsComponent } from '../../admin/broadcaststats.component';
import { GetsendreclistComponent } from '../../admin/getsendreclist.component';
import { AdminforwardComponent } from '../../admin/adminforward.component';
import { UseractiveComponent } from '../../admin/useractive.component';
import { UserinactiveComponent } from '../../admin/userinactive.component';
import { DataTablesModule } from 'angular-datatables';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgxSummernoteModule } from 'ngx-summernote';
import { AvatarModule } from 'ngx-avatar';
import { Adminroutes } from './adminrouting';


const avatarColors = ["rgb(224, 40, 67)", "#212e77", "#237177", "#e79105", "#5d9208"];

@NgModule({
  declarations: [
    AdminDashboardComponent,
    ManageGroupComponent,
    ManageUserComponent,
    UserlistComponent,
    ResetPassComponent,
    BroadcastComponent,
    SendReceivestatsComponent,
    UsernotusingmboardComponent,
    LastloginComponent,
    MsgReportComponent,
    AdminprofileComponent,
    AdminmailboxComponent,
    AdminmailboxinfoComponent,
    AdmincreateComponent,
    AdminsentmailComponent,
    AdminsentdetailsComponent,
    AdminimportantComponent,
    AdmindraftComponent,
    AdmindraftcomComponent,
    AdminarchiveComponent,
    AdminartrashComponent,
    BroadcaststatsComponent,
    GetsendreclistComponent,
    AdminforwardComponent,
    UseractiveComponent,
    UserinactiveComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(Adminroutes),
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.doubleBounce,
      backdropBorderRadius: '4px',
      primaryColour: '#25476a',
      secondaryColour: '#25476a',
      tertiaryColour: '#25476a',
      fullScreenBackdrop: true
    }),
    NgxSpinnerModule,
    NgMultiSelectDropDownModule.forRoot(),
    NgxPaginationModule,
    Ng2SearchPipeModule,
    NgDatepickerModule,
    NgxSummernoteModule,
    AvatarModule.forRoot({
      colors: avatarColors
    }),

  ]
})
export class AdminModule { }





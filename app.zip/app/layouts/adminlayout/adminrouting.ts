
import { ManageUserComponent } from './../../admin/manage-user.component';
import { Routes, RouterModule } from '@angular/router';
import { AdminDashboardComponent } from './../../admin/admin-dashboard.component';
import { AdminauthGuard } from './../../gaurds/adminauth.guard';
import { UserlistComponent } from './../../admin/user-list.component';
import { ResetPassComponent } from './../../admin/reset-pass.component';
import { BroadcastComponent } from './../../admin/broadcast.component';
import { BroadcaststatsComponent } from './../../admin/broadcaststats.component';
import { SendReceivestatsComponent } from './../../admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './../../admin/usernotusingmboard.component';
import { LastloginComponent } from './../../admin/lastlogin.component';
import { MsgReportComponent } from './../../admin/msg-report.component';
import { AdminprofileComponent } from './../../admin/admin-profile.component';
import { GetsendreclistComponent } from './../../admin/getsendreclist.component';
import { AdminmailboxComponent } from './../../admin/adminmailbox.component';
import { AdminmailboxinfoComponent } from './../../admin/adminmailboxinfo.component';
import { AdmincreateComponent } from './../../admin/admincreate.component';
import { AdminsentmailComponent } from './../../admin/adminsentmail.component';
import { AdminsentdetailsComponent } from './../../admin/adminsentdetails.component';
import { AdminimportantComponent } from './../../admin/adminimportant.component';
import { AdmindraftComponent } from './../../admin/admindraft.component';
import { AdmindraftcomComponent } from './../../admin/admindraftcom.component';
import { AdminarchiveComponent } from './../../admin/adminarchive.component';
import { AdminartrashComponent } from './../../admin/adminartrash.component';
import { AdminforwardComponent } from './../../admin/adminforward.component';
import { ManageGroupComponent } from './../../admin/manage-group.component';



export const Adminroutes: Routes = [



    { path: 'dashboard', component: AdminDashboardComponent },
    { path: 'managegroup', component: ManageGroupComponent, },
    { path: 'manageuser', component: ManageUserComponent },
    { path: 'userlist', component: UserlistComponent },
    { path: ':dpt/resetPassword', component: ResetPassComponent },
    { path: 'broadcast', component: BroadcastComponent },
    { path: 'broadstats', component: BroadcaststatsComponent },
    { path: 'statistics', component: SendReceivestatsComponent },
    { path: 'usernoactivated', component: UsernotusingmboardComponent },
    { path: 'lastloginrpt', component: LastloginComponent },
    { path: 'messagerpt', component: MsgReportComponent },
    { path: 'adminprofile', component: AdminprofileComponent },
    { path: 'msgdetails/:uid/:flag', component: GetsendreclistComponent },


    { path: 'mailbox', component: AdminmailboxComponent },
    { path: 'mailinfo/:aml/:ams', component: AdminmailboxinfoComponent },
    { path: 'create', component: AdmincreateComponent },
    { path: 'sentmail', component: AdminsentmailComponent },
    { path: 'sendDetails/:amessageid', component: AdminsentdetailsComponent },
    { path: 'aimportant', component: AdminimportantComponent },
    { path: 'admindraft', component: AdmindraftComponent },
    { path: 'admindraftcom/:amailid', component: AdmindraftcomComponent },
    { path: 'adminarchive', component: AdminarchiveComponent },
    { path: 'admintrash', component: AdminartrashComponent },
    { path: 'forwordmail/:afml', component: AdminforwardComponent },

    //********************************User */

];


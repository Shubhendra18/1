import { ManageadminComponent } from './../../superadmin/manageadmin.component';
import { SuperadminprofileComponent } from './../../superadmin/superadminprofile.component';
import { DepartmentlistComponent } from './../../superadmin/departmentlist.component';
import { AdddepartmentComponent } from './../../superadmin/adddepartment.component';
import { SdahboardComponent } from './../../superadmin/sdahboard.component';
import { SuperadminloginComponent } from './../../superadmin/superadminlogin.component';
import { Routes } from '@angular/router';




export const SuperAdminroutes: Routes = [

    { path: 'administrator', component: SuperadminloginComponent },
    { path: 'Controlpanel', component: SdahboardComponent },
    { path: 'addDpt', component: AdddepartmentComponent },
    { path: 'dptList', component: DepartmentlistComponent },
    { path: 'manageProfile', component: SuperadminprofileComponent },
    { path: 'adminlist', component: ManageadminComponent },


];


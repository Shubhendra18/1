import { AdddepartmentComponent } from './../../superadmin/adddepartment.component';
import { ManageadminComponent } from './../../superadmin/manageadmin.component';
import { SuperadminprofileComponent } from './../../superadmin/superadminprofile.component';
import { DepartmentlistComponent } from './../../superadmin/departmentlist.component';
import { SdahboardComponent } from './../../superadmin/sdahboard.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgxSummernoteModule } from 'ngx-summernote';
import { AvatarModule } from 'ngx-avatar';
import { SuperAdminroutes } from './superadminrouting';


const avatarColors = ["rgb(224, 40, 67)", "#212e77", "#237177", "#e79105", "#5d9208"];

@NgModule({
  declarations: [
    SdahboardComponent,
    AdddepartmentComponent,
    DepartmentlistComponent,
    SuperadminprofileComponent,
    ManageadminComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(SuperAdminroutes),
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.doubleBounce,
      backdropBorderRadius: '4px',
      primaryColour: '#25476a',
      secondaryColour: '#25476a',
      tertiaryColour: '#25476a',
      fullScreenBackdrop: true
    }),
    NgxSpinnerModule,
    NgMultiSelectDropDownModule.forRoot(),
    NgxPaginationModule,
    Ng2SearchPipeModule,
    NgDatepickerModule,
    NgxSummernoteModule,
    AvatarModule.forRoot({
      colors: avatarColors
    }),

  ]
})
export class SuperAdminModule { }





import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superadminlayout',
  templateUrl: './superadminlayout.component.html',
  styles: []
})
export class SuperAdminlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

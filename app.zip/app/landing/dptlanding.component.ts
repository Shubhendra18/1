import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-dptlanding',
  templateUrl: './dptlanding.component.html',
  styleUrls: ['../user/user-login.component.css',]
})
export class DptlandingComponent implements OnInit {
  encrpt: string;
  plainText: string;
  public loading = false;
  dptId: any;
  constructor(private service: MailboxserviceService, private router: Router) {
  }
  ngOnInit() {

  }
  dptselect(dptData) {
    this.loading = true;
    this.service.Departmentinfo(dptData.value).subscribe((data: any) => {
      this.dptId = data['result'].departmentId;
      this.plainText = data['result'].departmentId;
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "dpt").toString();
      localStorage.setItem('dptId', this.encrpt);
      this.loading = false;
      this.router.navigate(['', this.dptId]);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: "Invalid!",
          text: err.error.error,
        })
        this.loading = false;
      };
    });
  }
}

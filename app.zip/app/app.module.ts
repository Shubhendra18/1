import { ComponentsModule } from './components/components.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { NgModule, enableProdMode } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import Swal from 'sweetalert2';
import { ToastrModule } from 'ngx-toastr';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';

import { MailboxserviceService } from './mailboxservice.service';

import { AuthGuard } from './gaurds/auth.guard';
import { AdminauthGuard } from './gaurds/adminauth.guard';
import { AppPasswordDirective } from './common/app-password.directive';
import { AdminlayoutComponent } from './layouts/adminlayout/adminlayout.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { DptselectorComponent } from './landing/dptselector.component';
import { SuperadminloginComponent } from './superadmin/superadminlogin.component';
import { ErrorpageComponent } from './common/errorpage.component';
import { DptlandingComponent } from './landing/dptlanding.component';
import { SuperAdminlayoutComponent } from './layouts/superadminlayout/superadminlayout.component';


enableProdMode();
@NgModule({
  declarations: [
    AdminlayoutComponent,
    SuperAdminlayoutComponent,
    AppComponent,
    AdminLoginComponent,
    AppPasswordDirective,
    DptselectorComponent,
    SuperadminloginComponent,
    ErrorpageComponent,
    DptlandingComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    CommonModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      closeButton: true,
      progressBar: true,
      progressAnimation: 'decreasing',
      positionClass: 'toast-top-center',
      timeOut: 2000,
      preventDuplicates: true,
    }),
    ComponentsModule,
    RouterModule,
    NgxSpinnerModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.doubleBounce,
      backdropBorderRadius: '4px',
      primaryColour: '#25476a',
      secondaryColour: '#25476a',
      tertiaryColour: '#25476a',
      fullScreenBackdrop: true
    }),
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [MailboxserviceService, AuthGuard, AdminauthGuard, { provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }
